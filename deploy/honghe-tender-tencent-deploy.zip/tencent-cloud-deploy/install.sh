#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 root 运行：sudo bash install.sh"
  exit 1
fi

APP_DIR=/opt/honghe-tender
ENV_FILE=/etc/honghe-tender.env

echo "[1/8] 安装系统依赖"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip ca-certificates

echo "[2/8] 设置中国时区"
timedatectl set-timezone Asia/Shanghai

echo "[3/8] 创建运行用户和目录"
if ! id honghe >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin honghe
fi
mkdir -p "$APP_DIR"
cp -f daily_plan_workflow.py publish_github.py requirements.txt run_update.sh "$APP_DIR/"
chmod 755 "$APP_DIR/run_update.sh"
chown -R honghe:honghe "$APP_DIR"

echo "[4/8] 创建 Python 虚拟环境"
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

echo "[5/8] 配置 GitHub 发布令牌"
if [[ ! -s "$ENV_FILE" ]]; then
  echo "请输入只允许访问 honghe-tender-plan 仓库、Contents=Read and write 的 Fine-grained token"
  read -r -s -p "GITHUB_TOKEN: " GH_TOKEN
  echo
  if [[ -z "$GH_TOKEN" ]]; then
    echo "Token 不能为空"
    exit 1
  fi
  umask 077
  printf 'GITHUB_TOKEN=%s\n' "$GH_TOKEN" > "$ENV_FILE"
fi
chmod 600 "$ENV_FILE"
chown root:root "$ENV_FILE"

echo "[6/8] 安装 systemd 服务"
cp -f honghe-tender.service /etc/systemd/system/honghe-tender.service
cp -f honghe-tender.timer /etc/systemd/system/honghe-tender.timer
systemctl daemon-reload
systemctl enable honghe-tender.timer

echo "[7/8] 立即执行第一次更新"
systemctl start honghe-tender.service

echo "[8/8] 启动每日定时器"
systemctl start honghe-tender.timer
systemctl --no-pager --full status honghe-tender.service || true
systemctl list-timers honghe-tender.timer --no-pager

echo
echo "部署完成。公网地址：https://sadfdsfdsffewf.github.io/honghe-tender-plan/"
echo "查看日志：journalctl -u honghe-tender.service -f"