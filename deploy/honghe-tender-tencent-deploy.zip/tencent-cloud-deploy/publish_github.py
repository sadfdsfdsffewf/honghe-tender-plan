# -*- coding: utf-8 -*-
"""Publish generated index.html to GitHub Contents API."""
from __future__ import annotations

import argparse
import base64
import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path

API = "https://api.github.com"


def request(method: str, url: str, token: str, payload: dict | None = None) -> tuple[int, dict]:
    body = None
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "honghe-tender-cloud-worker",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            text = response.read().decode("utf-8", "replace")
            return response.status, json.loads(text) if text else {}
    except urllib.error.HTTPError as exc:
        text = exc.read().decode("utf-8", "replace")
        raise RuntimeError(f"GitHub API HTTP {exc.code}: {text[:500]}") from exc


def get_remote_file(repo: str, path: str, branch: str, token: str) -> dict | None:
    url = f"{API}/repos/{repo}/contents/{path}?ref={branch}"
    try:
        _, data = request("GET", url, token)
        return data
    except RuntimeError as exc:
        if "HTTP 404" in str(exc):
            return None
        raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default="sadfdsfdsffewf/honghe-tender-plan")
    parser.add_argument("--path", default="index.html")
    parser.add_argument("--source", default="output/publish/index.html")
    parser.add_argument("--branch", default="main")
    args = parser.parse_args()

    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if not token:
        raise SystemExit("缺少 GITHUB_TOKEN 环境变量")

    source = Path(args.source)
    if not source.exists():
        raise SystemExit(f"找不到待发布页面: {source}")
    data = source.read_bytes()
    encoded = base64.b64encode(data).decode("ascii")

    remote = get_remote_file(args.repo, args.path, args.branch, token)
    if remote:
        remote_content = (remote.get("content") or "").replace("\n", "").replace("\r", "")
        if remote_content == encoded:
            print("公网页面内容未变化，无需发布。")
            return

    payload = {
        "message": time.strftime("Cloud update %Y-%m-%d %H:%M:%S"),
        "content": encoded,
        "branch": args.branch,
    }
    if remote and remote.get("sha"):
        payload["sha"] = remote["sha"]

    url = f"{API}/repos/{args.repo}/contents/{args.path}"
    last_error = None
    for attempt in range(1, 5):
        try:
            _, result = request("PUT", url, token, payload)
            commit = (result.get("commit") or {}).get("sha", "")
            print(f"公网页面发布成功，commit={commit}")
            return
        except Exception as exc:
            last_error = exc
            print(f"发布尝试 {attempt}/4 失败: {exc}")
            if attempt < 4:
                time.sleep(5 * attempt)
    raise SystemExit(f"公网页面发布失败: {last_error}")


if __name__ == "__main__":
    main()