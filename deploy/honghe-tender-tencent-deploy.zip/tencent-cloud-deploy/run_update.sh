#!/usr/bin/env bash
set -euo pipefail
cd /opt/honghe-tender
export PYTHONUNBUFFERED=1
mkdir -p data output logs _cache_plan _cache_zbgg
/opt/honghe-tender/.venv/bin/python daily_plan_workflow.py --bootstrap-days 180 --cache-hours 0

# 腾讯云 Nginx 直接读取 output/publish，不再依赖 GitHub 才能展示页面。
# GitHub 仅作为可选备份，发布失败不会影响云端主站更新。
if [[ "${PUBLISH_GITHUB:-1}" == "1" && -n "${GITHUB_TOKEN:-}" ]]; then
  /opt/honghe-tender/.venv/bin/python publish_github.py \
    --repo sadfdsfdsffewf/honghe-tender-plan \
    --path index.html \
    --source output/publish/index.html \
    --branch main \
    || echo "WARNING: GitHub backup publish failed; Tencent direct site is still updated."
fi