#!/usr/bin/env bash
set -euo pipefail
cd /opt/honghe-tender
export PYTHONUNBUFFERED=1
mkdir -p data output logs _cache_plan _cache_zbgg
/opt/honghe-tender/.venv/bin/python daily_plan_workflow.py --bootstrap-days 180 --cache-hours 0
/opt/honghe-tender/.venv/bin/python publish_github.py --repo sadfdsfdsffewf/honghe-tender-plan --path index.html --source output/publish/index.html --branch main