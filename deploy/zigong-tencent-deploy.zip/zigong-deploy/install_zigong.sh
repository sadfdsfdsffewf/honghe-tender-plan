#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 sudo bash install_zigong.sh"
  exit 1
fi

APP_DIR=/opt/zigong
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT

curl -fL --connect-timeout 15 --max-time 180 \
  -o "$TMP_DIR/zigong.zip" \
  "https://sadfdsfdsffewf.github.io/honghe-tender-plan/deploy/zigong-tencent-deploy.zip?v=$(date +%s)"
unzip -o "$TMP_DIR/zigong.zip" -d "$TMP_DIR/pkg" >/dev/null

mkdir -p "$APP_DIR"
install -o honghe -g honghe -m 0644 "$TMP_DIR/pkg/zigong-deploy/zigong_workflow.py" "$APP_DIR/zigong_workflow.py"
install -o honghe -g honghe -m 0644 "$TMP_DIR/pkg/zigong-deploy/site_template.html" "$APP_DIR/site_template.html"
install -o honghe -g honghe -m 0755 "$TMP_DIR/pkg/zigong-deploy/run_update.sh" "$APP_DIR/run_update.sh"
install -o root -g root -m 0644 "$TMP_DIR/pkg/zigong-deploy/zigong-tender.service" /etc/systemd/system/zigong-tender.service
install -o root -g root -m 0644 "$TMP_DIR/pkg/zigong-deploy/zigong-tender.timer" /etc/systemd/system/zigong-tender.timer
chown -R honghe:honghe "$APP_DIR"

if [[ -f /etc/caddy/Caddyfile && ! -f /etc/caddy/Caddyfile.before-zigong ]]; then
  cp -a /etc/caddy/Caddyfile /etc/caddy/Caddyfile.before-zigong
fi

cat >/etc/caddy/Caddyfile <<'EOF'
:80 {
    handle_path /zigong/* {
        root * /opt/zigong/output/publish
        try_files {path} /index.html
        file_server
    }

    handle {
        root * /opt/honghe-tender/output/publish
        try_files {path} /index.html
        file_server
    }

    encode gzip
    header Cache-Control "no-cache, no-store, must-revalidate"
}
EOF

systemctl daemon-reload
systemctl reload caddy || systemctl restart caddy
systemctl enable --now zigong-tender.timer
systemctl start zigong-tender.service

echo "自贡站点：http://118.24.53.186/zigong/"