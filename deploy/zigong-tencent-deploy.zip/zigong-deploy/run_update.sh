#!/usr/bin/env bash
set -euo pipefail
cd /opt/zigong
mkdir -p data output/publish
/usr/bin/python3 zigong_workflow.py