# -*- coding: utf-8 -*-
"""自贡市招标计划与招标公告抓取工作流。"""
from __future__ import annotations

import json
import re
import time
import urllib.request
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
PUBLISH_DIR = OUTPUT_DIR / "publish"
for directory in (DATA_DIR, OUTPUT_DIR, PUBLISH_DIR):
    directory.mkdir(parents=True, exist_ok=True)

BASE_URL = "https://ggzyjy.sc.gov.cn"
SEARCH_API = BASE_URL + "/inteligentsearch/rest/esinteligentsearch/getFullTextDataNew"
PLAN_CATEGORY = "002001009"
ANNOUNCEMENT_CATEGORY = "002001001"
ZIGONG_SOURCE = "S009"
FETCH_DAYS = 180
UNKNOWN_DEADLINE_DAYS = 30
REQUEST_INTERVAL = 0.30
TZ_CN = timezone(timedelta(hours=8))
REGIONS = ["高新区", "自流井区", "贡井区", "大安区", "沿滩区", "富顺县", "荣县", "自贡市"]

HDRS = {
    "Content-Type": "application/json;charset=UTF-8",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
    "Referer": BASE_URL + "/jyxx/transactionInfo.html",
    "Origin": BASE_URL,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
}


def now_cn() -> datetime:
    return datetime.now(TZ_CN)


def clean_text(value: Any) -> str:
    text = str(value or "").replace("&nbsp;", " ").replace("\u00a0", " ")
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def compact(value: Any, limit: int = 8000) -> str:
    text = clean_text(value)
    return text[:limit]


def parse_datetime(value: Any) -> datetime | None:
    text = clean_text(value)
    if not text:
        return None
    normalized = text.replace("年", "-").replace("月", "-").replace("日", " ").replace("时", ":").replace("分", ":")
    match = re.search(
        r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})"
        r"(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?",
        normalized,
    )
    if not match:
        return None
    y, mo, d, hh, mm, ss = match.groups()
    try:
        return datetime(int(y), int(mo), int(d), int(hh or 0), int(mm or 0), int(ss or 0), tzinfo=TZ_CN)
    except ValueError:
        return None


def iso(value: datetime | None) -> str:
    return value.isoformat(timespec="seconds") if value else ""


def display_dt(value: datetime | None) -> str:
    return value.strftime("%Y-%m-%d %H:%M") if value else ""


def full_url(link: Any) -> str:
    link_text = str(link or "").strip()
    if not link_text:
        return ""
    if link_text.startswith("http://") or link_text.startswith("https://"):
        return link_text
    return BASE_URL + (link_text if link_text.startswith("/") else "/" + link_text)


def region_from_title(title: str) -> str:
    for region in REGIONS:
        if region in title:
            return region
    return "自贡市"


def condition(field: str, equal: Any, **kwargs: Any) -> dict[str, Any]:
    value = {
        "fieldName": field,
        "equal": equal,
        "notEqual": None,
        "equalList": None,
        "notEqualList": None,
    }
    value.update(kwargs)
    return value


def fetch_category(category: str, start: datetime, end: datetime) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    page = 0
    total = None
    while True:
        payload = {
            "token": "",
            "pn": page,
            "rn": 12,
            "wd": "",
            "fields": "",
            "cnum": "",
            "sort": '{"webdate":"0"}',
            "cl": 10000,
            "condition": [
                condition("tradingsourcevalue", ZIGONG_SOURCE),
                condition("categorynum", category, isLike=True, likeType=2),
            ],
            "time": [{
                "fieldName": "webdate",
                "startTime": start.strftime("%Y-%m-%d 00:00:00"),
                "endTime": end.strftime("%Y-%m-%d 23:59:59"),
            }],
            "noWd": True,
        }
        request = urllib.request.Request(
            SEARCH_API,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers=HDRS,
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
        result = data.get("result") or {}
        if total is None:
            total = int(result.get("totalcount") or 0)
        batch = result.get("records") or []
        records.extend(batch)
        print(f"  {category}: {len(records)}/{total}", flush=True)
        page += 12
        if page >= total or not batch:
            break
        time.sleep(REQUEST_INTERVAL)
    return records

def between(text: str, start_label: str, end_labels: list[str]) -> str:
    start = text.find(start_label)
    if start < 0:
        return ""
    start += len(start_label)
    end = len(text)
    for label in end_labels:
        idx = text.find(label, start)
        if idx >= 0:
            end = min(end, idx)
    return text[start:end].strip()


def first_match(pattern: str, text: str, default: str = "") -> str:
    match = re.search(pattern, text, re.S)
    return clean_text(match.group(1)) if match else default


def parse_contact(value: str) -> tuple[str, str]:
    text = clean_text(value)
    if not text:
        return "", ""
    match = re.search(r"(.+?)[：:]\s*([0-9+\-()（）]{6,30})", text)
    if match:
        return clean_text(match.group(1)), clean_text(match.group(2))
    match = re.search(r"([0-9+\-()（）]{6,30})", text)
    return clean_text(text.replace(match.group(1), "") if match else text), clean_text(match.group(1)) if match else ""


def parse_plan(record: dict[str, Any], now: datetime) -> dict[str, Any] | None:
    content = clean_text(record.get("content"))
    title = clean_text(record.get("title"))
    name = first_match(r"招标项目名称\s+(.+?)\s+项目批准文件", content)
    if not name:
        name = re.sub(r"招标计划(?:公告)?$", "", title).strip()
    tenderer = first_match(r"招标人\s+(.+?)\s+联系人及联系方式", content)
    contact_raw = between(content, "联系人及联系方式", ["估算总投资（元）"])
    contact, phone = parse_contact(contact_raw)
    amount_raw = first_match(r"估算总投资（元）\s*([0-9,.]+)", content)
    amount = round(float(amount_raw.replace(",", "")) / 10000, 6) if amount_raw else None
    category = between(content, "项目分类", ["招标项目概况", "拟招标内容"])
    overview = between(content, "招标项目概况", ["拟招标内容", "备注"])
    expected_section = between(content, "拟招标内容", ["备注"])
    expected_dates = []
    for match in re.finditer(r"20\d{2}[-年]\d{1,2}[-月]\d{1,2}日?(?:\s*\d{1,2}时\d{1,2}分)?", expected_section):
        parsed = parse_datetime(match.group(0))
        if parsed:
            expected_dates.append(parsed)
    expected = max(expected_dates) if expected_dates else None
    if expected and expected <= now:
        return None
    published = parse_datetime(record.get("webdate") or record.get("infodate"))
    link = full_url(record.get("linkurl"))
    return {
        "guid": record.get("id") or record.get("syscollectguid") or link,
        "name": name,
        "amount": amount,
        "tenderer": tenderer,
        "area": region_from_title(title or name),
        "department": record.get("zhuanzai") or "自贡市公共资源交易服务中心",
        "deadline": display_dt(expected),
        "deadlineMs": int(expected.timestamp() * 1000) if expected else None,
        "deadlineIso": iso(expected),
        "contact": contact,
        "phone": phone,
        "nature": "招标计划",
        "published": published.strftime("%Y-%m-%d") if published else clean_text(record.get("webdate")),
        "publishedAt": iso(published),
        "platform": "自贡市",
        "content": compact(overview, 6000),
        "remark": link,
        "projectType": category,
        "source": "",
        "scale": compact(overview, 6000),
        "reviewMethod": "",
        "tendererPhone": phone,
        "agency": "",
        "agencyContact": "",
        "agencyOfficePhone": "",
        "agencyMobilePhone": "",
        "qualification": "",
        "openTime": "",
        "docDeadline": "",
        "bidDeadline": "",
        "bondDeadline": "",
        "bidBond": "",
        "announcementEnd": "",
        "rawContent": compact(content, 8000),
    }

def extract_deadlines(content: str) -> dict[str, datetime | None]:
    patterns = {
        "docDeadline": [
            r"(?:招标文件获取截止时间|招标文件获取的截止时间|获取招标文件截止时间)[^。]{0,100}?(20\d{2}年\d{1,2}月\d{1,2}日\s*\d{1,2}时\d{1,2}分)",
        ],
        "bidDeadline": [
            r"(?:投标文件递交的截止时间|投标截止时间)[^。]{0,120}?为\s*(20\d{2}年\d{1,2}月\d{1,2}日\s*\d{1,2}时\d{1,2}分)",
        ],
        "bondDeadline": [
            r"(?:投标保证金.{0,30}?缴纳截止时间|投标保证金.{0,30}?截止时间)[^。]{0,100}?(20\d{2}年\d{1,2}月\d{1,2}日\s*\d{1,2}时\d{1,2}分)",
        ],
    }
    result: dict[str, datetime | None] = {}
    for key, choices in patterns.items():
        value = None
        for pattern in choices:
            match = re.search(pattern, content, re.S)
            if match:
                value = parse_datetime(match.group(1))
                if value:
                    break
        result[key] = value
    return result


def parse_announcement(record: dict[str, Any], now: datetime) -> dict[str, Any] | None:
    content = clean_text(record.get("content"))
    title = clean_text(record.get("title"))
    name = re.sub(r"招标公告$", "", title).strip() or title
    tenderer = first_match(r"招标人为\s*([^。；]+?)\s*[。；]", content)
    if not tenderer:
        tenderer = first_match(r"招\s*标\s*人\s*[：:]\s*([^。；\n]+)", content)
    agency = first_match(r"招标代理机构是\s*([^。；\n]+)", content)
    if not agency:
        agency = first_match(r"招标代理机构\s*[：:]\s*([^。；\n]+)", content)
    contact_block = content
    index = content.rfind("联系方式")
    if index >= 0:
        contact_block = content[index:]
    contact = first_match(r"联\s*系\s*人\s*[：:]\s*([^，。；\n]{1,24})", contact_block)
    phone = first_match(r"(?:电\s*话|联系电话)\s*[：:]\s*([0-9+\-()（）]{6,30})", contact_block)
    source = first_match(r"建设资金来自\s*([^，。；]+)", content)
    amount_raw = first_match(r"投资额\s*[：:]\s*([0-9,.]+)\s*万元", content)
    if not amount_raw:
        amount_raw = first_match(r"(?:最高投标限价|招标控制价)[^0-9]{0,20}([0-9,.]+)\s*万元", content)
    amount = float(amount_raw.replace(",", "")) if amount_raw else None
    scale = between(content, "建设内容及规模", ["投资额", "招标范围"])
    qualification = between(content, "3.1.1资质条件", ["3.1.2", "3.2"])
    deadlines = extract_deadlines(content)
    valid_deadlines = [value for value in deadlines.values() if value]
    deadline = min(valid_deadlines) if valid_deadlines else None
    published = parse_datetime(record.get("webdate") or record.get("infodate"))
    if any(value <= now for value in valid_deadlines):
        return None
    if not valid_deadlines and published and published < now - timedelta(days=UNKNOWN_DEADLINE_DAYS):
        return None
    project_type = "施工"
    upper = name + " " + content[:500]
    for keyword in ["监理", "设计", "勘察", "货物", "设备", "EPC", "总承包"]:
        if keyword in upper:
            project_type = keyword
            break
    review = "资格预审" if "资格预审" in content[:3000] else ("资格后审" if "资格后审" in content[:3000] else "")
    bid_bond = first_match(r"投标保证金[^0-9]{0,30}([0-9,.]+)\s*万元", content)
    link = full_url(record.get("linkurl"))
    return {
        "guid": record.get("id") or record.get("syscollectguid") or link,
        "name": name,
        "amount": amount,
        "tenderer": tenderer,
        "area": region_from_title(title or name),
        "department": "自贡市公共资源交易服务中心",
        "deadline": display_dt(deadline),
        "deadlineMs": int(deadline.timestamp() * 1000) if deadline else None,
        "deadlineIso": iso(deadline),
        "contact": contact,
        "phone": phone,
        "nature": "招标公告",
        "published": published.strftime("%Y-%m-%d") if published else clean_text(record.get("webdate")),
        "publishedAt": iso(published),
        "platform": "自贡市",
        "content": compact(content, 8000),
        "remark": link,
        "source": source,
        "scale": compact(scale, 6000),
        "projectType": project_type,
        "reviewMethod": review,
        "tendererPhone": phone,
        "agency": agency,
        "agencyContact": contact,
        "agencyOfficePhone": "",
        "agencyMobilePhone": "",
        "qualification": compact(qualification, 4000),
        "openTime": display_dt(deadlines["bidDeadline"]),
        "docDeadline": display_dt(deadlines["docDeadline"]),
        "bidDeadline": display_dt(deadlines["bidDeadline"]),
        "bondDeadline": display_dt(deadlines["bondDeadline"]),
        "bidBond": bid_bond + " 万元" if bid_bond else "",
        "announcementEnd": display_dt(deadlines["bidDeadline"]),
        "rawContent": compact(content, 8000),
    }

def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def atomic_json(path: Path, value: Any) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def record_signature(record: dict[str, Any]) -> str:
    keys = ["name", "amount", "tenderer", "area", "deadline", "published", "content", "remark"]
    return json.dumps({key: record.get(key) for key in keys}, ensure_ascii=False, sort_keys=True)


def compare_records(previous: dict[str, Any], active: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    old = {str(item.get("guid")): item for item in previous.get("records", [])}
    added, updated = [], []
    for item in active:
        key = str(item.get("guid"))
        if key not in old:
            added.append(item)
        elif record_signature(old[key]) != record_signature(item):
            updated.append(item)
    return added, updated


def build_plan_summary(run_at: datetime, active: list[dict[str, Any]], excluded: int, added: list[dict[str, Any]], updated: list[dict[str, Any]]) -> dict[str, Any]:
    total = sum(float(item["amount"]) for item in active if item.get("amount") is not None)
    soon = [item for item in active if item.get("deadlineMs") and run_at.timestamp() * 1000 < item["deadlineMs"] <= (run_at + timedelta(days=7)).timestamp() * 1000]
    return {
        "run_at": iso(run_at),
        "active_count": len(active),
        "active_total_amount_wan": round(total, 2),
        "added_count": len(added),
        "updated_count": len(updated),
        "expired_count": excluded,
        "soon_7d_count": len(soon),
        "soon_7d": [
            {"name": item["name"], "deadline": item.get("deadline", ""), "area": item.get("area", ""), "amount": item.get("amount"), "contact": item.get("contact", ""), "phone": item.get("phone", "")}
            for item in soon[:12]
        ],
        "added_names": [item.get("name", "") for item in added[:20]],
        "updated_names": [item.get("name", "") for item in updated[:20]],
    }


def build_announcement_summary(run_at: datetime, active: list[dict[str, Any]], excluded: int, added: list[dict[str, Any]], updated: list[dict[str, Any]]) -> dict[str, Any]:
    ending = [item for item in active if item.get("deadlineMs") and run_at.timestamp() * 1000 < item["deadlineMs"] <= (run_at + timedelta(days=7)).timestamp() * 1000]
    return {
        "run_at": iso(run_at),
        "active_count": len(active),
        "ending_7d_count": len(ending),
        "expired_count": excluded,
        "added_count": len(added),
        "updated_count": len(updated),
        "ending_7d": [
            {"name": item["name"], "deadline": item.get("deadline", ""), "area": item.get("area", ""), "amount": item.get("amount"), "tenderer": item.get("tenderer", "")}
            for item in sorted(ending, key=lambda value: value.get("deadlineMs") or 10**20)[:12]
        ],
        "added_names": [item.get("name", "") for item in added[:20]],
        "updated_names": [item.get("name", "") for item in updated[:20]],
    }


def make_payload(plans: list[dict[str, Any]], announcements: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    plan_payload = [{
        "name": item.get("name", ""),
        "amount": item.get("amount"),
        "tenderer": item.get("tenderer", ""),
        "area": item.get("area", ""),
        "department": item.get("department", ""),
        "deadline": item.get("deadline", ""),
        "deadlineMs": item.get("deadlineMs"),
        "contact": item.get("contact", ""),
        "phone": item.get("phone", ""),
        "nature": item.get("nature", ""),
        "published": item.get("published", ""),
        "publishedAt": item.get("publishedAt", ""),
        "platform": item.get("platform", ""),
        "content": item.get("content", ""),
        "remark": item.get("remark", ""),
    } for item in plans]
    announcement_payload = [{
        "name": item.get("name", ""),
        "projectCode": item.get("guid", ""),
        "amount": item.get("amount"),
        "source": item.get("source", ""),
        "scale": item.get("scale", ""),
        "projectType": item.get("projectType", ""),
        "reviewMethod": item.get("reviewMethod", ""),
        "tenderer": item.get("tenderer", ""),
        "tendererPhone": item.get("tendererPhone", ""),
        "agency": item.get("agency", ""),
        "agencyContact": item.get("agencyContact", ""),
        "agencyOfficePhone": item.get("agencyOfficePhone", ""),
        "agencyMobilePhone": item.get("agencyMobilePhone", ""),
        "area": item.get("area", ""),
        "department": item.get("department", ""),
        "deadline": item.get("deadline", ""),
        "deadlineMs": item.get("deadlineMs"),
        "announcementEnd": item.get("announcementEnd", ""),
        "contact": item.get("contact", ""),
        "phone": item.get("phone", ""),
        "nature": item.get("nature", ""),
        "published": item.get("published", ""),
        "publishedAt": item.get("publishedAt", ""),
        "platform": item.get("platform", ""),
        "content": item.get("content", ""),
        "remark": item.get("remark", ""),
        "qualification": item.get("qualification", ""),
        "openTime": item.get("openTime", ""),
        "docDeadline": item.get("docDeadline", ""),
        "bidDeadline": item.get("bidDeadline", ""),
        "bondDeadline": item.get("bondDeadline", ""),
        "bidBond": item.get("bidBond", ""),
    } for item in announcements]
    return plan_payload, announcement_payload


def main() -> None:
    run_at = now_cn()
    start = run_at - timedelta(days=FETCH_DAYS)
    print(f"抓取窗口：{start:%Y-%m-%d} ~ {run_at:%Y-%m-%d}")
    plan_records = fetch_category(PLAN_CATEGORY, start, run_at)
    announcement_records = fetch_category(ANNOUNCEMENT_CATEGORY, start, run_at)

    plans = []
    plan_duplicates = set()
    for record in plan_records:
        parsed = parse_plan(record, run_at)
        if parsed and parsed["name"] and parsed["guid"] not in plan_duplicates:
            plan_duplicates.add(parsed["guid"])
            plans.append(parsed)
    announcements = []
    announcement_duplicates = set()
    for record in announcement_records:
        parsed = parse_announcement(record, run_at)
        if parsed and parsed["name"] and parsed["guid"] not in announcement_duplicates:
            announcement_duplicates.add(parsed["guid"])
            announcements.append(parsed)

    plans.sort(key=lambda item: item.get("publishedAt") or "", reverse=True)
    announcements.sort(key=lambda item: item.get("publishedAt") or "", reverse=True)

    previous_plans = load_json(DATA_DIR / "plans_state.json", {})
    previous_announcements = load_json(DATA_DIR / "announcements_state.json", {})
    added_plans, updated_plans = compare_records(previous_plans, plans)
    added_announcements, updated_announcements = compare_records(previous_announcements, announcements)

    plan_summary = build_plan_summary(run_at, plans, len(plan_records) - len(plans), added_plans, updated_plans)
    announcement_summary = build_announcement_summary(run_at, announcements, len(announcement_records) - len(announcements), added_announcements, updated_announcements)

    plan_payload, announcement_payload = make_payload(plans, announcements)
    template = (BASE_DIR / "site_template.html").read_text(encoding="utf-8")
    html = (template
        .replace("__DATA_JSON__", json.dumps(plan_payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/"))
        .replace("__ANNOUNCEMENT_DATA_JSON__", json.dumps(announcement_payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/"))
        .replace("__SUMMARY_JSON__", json.dumps(plan_summary, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/"))
        .replace("__ANNOUNCEMENT_SUMMARY_JSON__", json.dumps(announcement_summary, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")))
    (PUBLISH_DIR / "index.html").write_text(html, encoding="utf-8")
    atomic_json(DATA_DIR / "plans.json", plans)
    atomic_json(DATA_DIR / "announcements.json", announcements)
    atomic_json(DATA_DIR / "plans_state.json", {"run_at": iso(run_at), "records": plans})
    atomic_json(DATA_DIR / "announcements_state.json", {"run_at": iso(run_at), "records": announcements})
    atomic_json(DATA_DIR / "latest_summary.json", {"plans": plan_summary, "announcements": announcement_summary})
    print(f"有效招标计划：{len(plans)}")
    print(f"有效招标公告：{len(announcements)}")
    print(f"页面：{PUBLISH_DIR / 'index.html'}")


if __name__ == "__main__":
    main()